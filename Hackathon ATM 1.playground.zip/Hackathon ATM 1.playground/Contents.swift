import UIKit

var greeting = "Hello, playground"

// Абстракция данных пользователя
protocol UserData {
    var userName: String { get }                          //Имя пользователя
    var userCardId: String { get }                        //Номер карты
    var userCardPin: Int { get }                          //Пин-код
    var userPhone: String { get }                         //Номер телефона
    var userCash: Float { get set }                       //Наличные пользователя
    var userBankDeposit: Float { get set }                //Банковский депозит
    var userPhoneBalance: Float { get set }               //Баланс телефона
    var userCardBalance: Float { get set }                //Баланс карты
}

// Тексты ошибок
enum TextErrors: String {
    case incorrect_PIN = "Неправильный ввод PIN-кода"
    case incorect_Number_User_Phone = "Введен неверный номер телефона"
    case not_Enough_Money_On_The_Deposit = "Не достаточно денежных средств на депозите"
    case not_Enough_Money_On_The_Card = "Не достаточно денежных средств на карте"
    case not_Enough_Cash = "Недостаточно наличных средств"
    case maximumNumberOfBanknotes = "Превышает максимальное допустимое количество купюр для одной операции"
}


// Виды операций, выбранных пользователем (подтверждение выбора)
enum DescriptionTypesAvailibleOperations: String {
    case balance = "Вы выбрали операцию запроса баланса"
    case phone = "Вы выбрали операцию пополнения баланса телефона"
    case withdrawal = "Вы выбрали операцию снятия наличных"
    case topUp = "Вы выбрали операцию пополнения"
}

// Действия, которые пользователь может выбирать в банкомате (имитация кнопок)
enum UserActions {
    case userPressBalanceInquiry                         //запрос баланса
    case userPressWithdrawalCash(withdraw: Float)        //снятие наличных
    case userPressTopUpAccount(topUp: Float)             //пополнение
    case userPressPayPhone(phone: String)                //пополнение баланса телефона
}


// Способ оплаты
enum PaymentMethod {
    case cash(cash: Float)                               //пополнение наличными
    case card(card: Float)                               //пополнение картой
}

//снятие наличных
enum WithdrawalMetod {
    case deposit                                         //снятие наличных со счета депозита
    case card                                            //снятие наличных со счета карты
}

//пополнение
enum TopUpMetod{
    case deposit//(deposit: Float)                       //пополнение счета депозита
    case card//(card: Float)                             //пополнение счета карты
}





// Банкомат, с которым мы работаем, имеет общедоступный интерфейс sendUserDataToBank
class ATM {
    private let userCardId: String
    private let userCardPin: Int
    private var someBank: BankApi
    private let actions: UserActions
    private let payment: PaymentMethod?
    private let withdrawal: WithdrawalMetod?
    private let topUping: TopUpMetod?
    private let maxBanknotes: Int?
    
    init(userCardId:String, userCardPin: Int, someBank: BankApi, actions: UserActions, payment: PaymentMethod? = nil, withdrawal: WithdrawalMetod? = nil, topUping: TopUpMetod? = nil, maxBanknotes: Int? = nil) {
                
            self.userCardId = userCardId
            self.userCardPin = userCardPin
            self.someBank = someBank
            self.actions = actions
            self.payment = payment
            self.withdrawal = withdrawal
            self.topUping = topUping
            self.maxBanknotes = maxBanknotes
            
        sendUserDataToBank(userCardId: userCardId, userCardPin: userCardPin, actions: actions, payment: payment, withdrawal: withdrawal, topUping: topUping, maxBanknotes: maxBanknotes)
            }
            
    public final func sendUserDataToBank(userCardId: String, userCardPin: Int, actions: UserActions, payment: PaymentMethod?, withdrawal: WithdrawalMetod?, topUping: TopUpMetod?, maxBanknotes:Int?){
                
        let isUserExist = someBank.checkCurrentUser(userCardId: userCardId, userCardPin: userCardPin)
            if isUserExist {
                switch actions {
                    case.userPressBalanceInquiry:
                        someBank.showUserDepositBalance()
                        someBank.showUserCardBalance()
                    
                    case let .userPressPayPhone(phone):
                        if someBank.chekUserPhone(phone: phone) {
                            if let payment = payment {
                            switch payment {
                                case let .cash(cash: payment):
                                    if someBank.checkMaxUserCash(cash: payment) {
                                        someBank.topUpPhoneBalanceCash(pay: payment)
                                        someBank.showUserToppedUpMobilePhoneCash(cash: payment)
                                } else {
                                      someBank.showError(error: .not_Enough_Cash)
                                }
                                case let .card(card: payment):
                                    if someBank.checkMaxUserCard(withdraw: payment) {
                                        someBank.topUpPhoneBalanceCard(pay: payment)
                                        someBank.showUserToppedUpMobilePhoneCard(card: payment)
                                } else{
                                    someBank.showError(error: .not_Enough_Money_On_The_Card)
                                }
                            }
                            }
                        } else {
                            someBank.showError(error: .incorect_Number_User_Phone)
                        }
//                    case let .userPressWithdrawalCash(withdraw):
//                        if someBank.checkMaxUserCard(withdraw: withdraw){
//                            someBank.getCashFromDeposit(cash: withdraw)
//                            someBank.getCashFromCard(cash: withdraw)
//                            someBank.showWithdrawalCard(cash: withdraw)
//                            someBank.showWithdrawalDeposit(cash: withdraw)
//                        } else{
//                            someBank.showError(error: .not_Enough_Money_On_The_Deposit)
//                        }
                    case let .userPressWithdrawalCash(withdraw):
                        if someBank.checkMaxUserDeposit(withdraw: withdraw) {
                            if let withdrawal = withdrawal {
                            switch withdrawal {
                            case .deposit://(deposit: withdraw):
                                if someBank.checkMaxUserDeposit(withdraw: withdraw) {
                                    someBank.getCashFromDeposit(cash: withdraw)
                                    someBank.showWithdrawalDeposit(cash: withdraw)
                                } else {
                                    someBank.showError(error: .not_Enough_Money_On_The_Deposit)
                                }
                            case .card://(card: withdraw):
                                if someBank.checkMaxUserCard(withdraw: withdraw) {
                                    someBank.getCashFromCard(cash: withdraw)
                                    someBank.showWithdrawalCard(cash: withdraw)
                                } else {
                                    someBank.showError(error: .not_Enough_Money_On_The_Card)
                                }
                                }

                           }

                     } else {
                        someBank.showError(error: .not_Enough_Money_On_The_Deposit)
                     }
                        
                    case let .userPressTopUpAccount(topUp):
                        if someBank.checkMaxUserCash(cash: topUp) {
                            if let topUping = topUping {
                                switch topUping {
                                case .card:
                                    if someBank.chekMaxOfBanknotes(banknotes: maxBanknotes!) {
                                        someBank.putCashCard(topUp: topUp)
                                        someBank.showTopUpCard(cash: topUp)
                                    } else {
                                        someBank.showError(error: .maximumNumberOfBanknotes)
                                    }
                                    
                                case .deposit:
                                    if  someBank.chekMaxOfBanknotes(banknotes: maxBanknotes!) {
                                        someBank.putCashDeposit(topUp: topUp)
                                        someBank.showTopUpDeposit(cash: topUp)
                                    } else {
                                        someBank.showError(error: .maximumNumberOfBanknotes)
                                    }
                                    
                                }
                            }
                        } else {
                            someBank.showError(error: .not_Enough_Cash)
                        }
                            
                }
                
            } else {
                someBank.showError(error: .incorrect_PIN)
                    
            }
     }
}

// Протокол по работе с банком предоставляет доступ к данным пользователя зарегистрированного в банке
protocol BankApi {
    func showUserCardBalance()
    func showUserDepositBalance()
    func showUserToppedUpMobilePhoneCash(cash: Float)
    func showUserToppedUpMobilePhoneCard(card: Float)
    //func showUserToppedUpMobilePhoneDeposit(cash: Float)
    func showWithdrawalCard(cash: Float)
    func showWithdrawalDeposit(cash: Float)
    func showTopUpCard(cash: Float)
    func showTopUpDeposit(cash: Float)
    func showError(error: TextErrors)

    func chekUserPhone(phone: String) -> Bool
    func checkMaxUserCash(cash: Float) -> Bool
    func checkMaxUserCard(withdraw: Float) -> Bool
    func checkMaxUserDeposit(withdraw: Float) -> Bool
    func checkCurrentUser(userCardId: String, userCardPin: Int) -> Bool
    func chekMaxOfBanknotes(banknotes: Int) -> Bool
    
    mutating func topUpPhoneBalanceCash(pay: Float)
    mutating func topUpPhoneBalanceCard(pay: Float)
//    mutating func topUpPhoneBalanceDeposit(pay: Float)
    mutating func getCashFromDeposit(cash: Float)
    mutating func getCashFromCard(cash: Float)
    mutating func putCashDeposit(topUp: Float)
    mutating func putCashCard(topUp: Float)
}


struct BankServer: BankApi {
    
    public func chekMaxOfBanknotes(banknotes maxBanknotes: Int) -> Bool {
        let a = maxBanknotes
        if a <= 40 {
            return true
        }
        return false
    }
   
    private var user: UserData
    
    init(user: UserData) {
        self.user = user
    }
    
    public func showUserCardBalance() {
        let report = """
        Ваш баланс карты составляет \(user.userCardBalance) рублей
        Хорошего дня!
        """
        print(report)
    }

    public func showUserDepositBalance() {
        let report = """
        Здравствуйте, \(user.userName)
        \(DescriptionTypesAvailibleOperations.balance.rawValue)
        Ваш баланс депозита составляет \(user.userBankDeposit) рублей
        """
        print(report)
    }

    public func showUserToppedUpMobilePhoneCash(cash: Float) {
        let report = """
        Здравствуйте, \(user.userName)
        \(DescriptionTypesAvailibleOperations.phone.rawValue)
        Вы пополнили баланс телефона \(user.userPhone) на сумму \(cash)рублей.
        У Вас осталось \(user.userCash) рублей наличными.
        Баланс Вашего телефона составляет \(user.userPhoneBalance) рублей.
        Хорошего дня!
        """
        print(report)
    }

    public func showUserToppedUpMobilePhoneCard(card: Float) {
        let report = """
        Здравствуйте, \(user.userName)
        \(DescriptionTypesAvailibleOperations.phone.rawValue)
        Вы пополнили баланс телефона \(user.userPhone) на сумму \(card)рублей.
        У Вас осталось на карте \(user.userCardBalance) рублей.
        Баланс Вашего телефона составляет \(user.userPhoneBalance) рублей.
        Хорошего дня!
        """
        print(report)
    }

    func showWithdrawalCard(cash: Float) {
        let report = """
        Здравствуйте, \(user.userName)
        \(DescriptionTypesAvailibleOperations.withdrawal.rawValue)
        Вы сняли с карты \(cash) рублей.
        Баланс Вашей карты составляет \(user.userCardBalance)
        У Вас осталось наличных \(user.userCash)
        Хорошего дня!
        """
        print(report)
    }

    func showWithdrawalDeposit(cash: Float) {
        let report = """
        Здравствуйте, \(user.userName)
        \(DescriptionTypesAvailibleOperations.withdrawal.rawValue)
        Вы сняли с депозита \(cash) рублей.
        Баланс средств депозита составляет \(user.userBankDeposit) рублей.
        У Вас осталось наличных \(user.userCash)
        Хорошего дня!
        """
        print(report)
    }

    func showTopUpCard(cash: Float) {
        let report = """
        Здравствуйте, \(user.userName)
        \(DescriptionTypesAvailibleOperations.topUp.rawValue)
        Вы пополнили баланс карты на сумму \(cash) рублей.
        Баланс средств счета карты составляет \(user.userCardBalance) рублей.
        У Вас осталось наличных \(user.userCash)
        Хорошего дня!
        """
        print(report)
    }

    func showTopUpDeposit(cash: Float) {
        let report = """
        Здравствуйте, \(user.userName)
        \(DescriptionTypesAvailibleOperations.topUp.rawValue)
        Вы пополнили баланс на сумму \(cash) рублей.
        Баланс средств депозита составляет \(user.userBankDeposit) рублей.
        У Вас осталось наличных \(user.userCash)
        Хорошего дня!
        """
        print(report)
    }

    func showError(error: TextErrors) {
        let error = """
        Здравствуйте, \(user.userName)
        Ошибка: \(error.rawValue)
        Хорошего дня!
        """
        print(error)
    }
    
    public mutating func topUpPhoneBalanceCash(pay: Float) {
        user.userPhoneBalance += pay
        user.userCash -= pay
    }

    public mutating func topUpPhoneBalanceCard(pay: Float) {
        user.userPhoneBalance += pay
        user.userCardBalance -= pay
    }

    public mutating func getCashFromDeposit(cash: Float) {
        user.userBankDeposit -= cash
        user.userCash += cash
    }

    public mutating func getCashFromCard(cash: Float) {
        user.userCardBalance -= cash
        user.userCash += cash
    }

    public mutating func putCashDeposit(topUp: Float) {
        user.userBankDeposit += topUp
        user.userCash -= topUp
    }

    public mutating func putCashCard(topUp: Float) {
        user.userCardBalance += topUp
        user.userCash -= topUp
    }

    public func chekUserPhone(phone: String) -> Bool {
        if phone == user.userPhone {
            return true
        }
        return false
        }

    public func checkMaxUserCash(cash: Float) -> Bool {
        if cash <= user.userCash {
            return true
        }
        return false
        }

    public func checkMaxUserCard(withdraw: Float) -> Bool {
        if withdraw <= user.userCardBalance {
            return true
        }
        return false
        }
    public func checkMaxUserDeposit(withdraw: Float) -> Bool {
        if withdraw <= user.userBankDeposit {
            return true
        }
        return false
        }

    public func checkCurrentUser(userCardId: String, userCardPin: Int) -> Bool {
        
        let isCorrectId = checkId(id: userCardId, user: user)
        let isCorrectPin = checkPin(pin: userCardPin, user: user)
        
        if isCorrectId && isCorrectPin {
            return true
        }
        return false
        }
    
    
    private func checkId(id: String, user: UserData) -> Bool {
        if id == user.userCardId {
            return true
        }
        return false
        }
    
    private func checkPin(pin: Int, user: UserData) -> Bool {
        if pin == user.userCardPin {
            return true
        }
        return false
        }
}



struct User: UserData {
    var userName: String                          //Имя пользователя
    var userCardId: String                        //Номер карты
    var userCardPin: Int                          //Пин-код
    var userPhone: String                         //Номер телефона
    var userCash: Float                           //Наличные пользователя
    var userBankDeposit: Float               //Банковский депозит
    var userPhoneBalance: Float               //Баланс телефона
    var userCardBalance: Float
}

let timur_garipov: UserData = User(
    userName: "Timur Garipov",                          //Имя пользователя
    userCardId: "4423 2500 6798 5925",                        //Номер карты
    userCardPin: 1234,                          //Пин-код
    userPhone: "+79158888888",                         //Номер телефона
    userCash: 3456.70,                           //Наличные пользователя
    userBankDeposit: 4565.56,                //Банковский депозит
    userPhoneBalance: -99.1,               //Баланс телефона
    userCardBalance: 4560.4
)
 let bankClint = BankServer(user: timur_garipov)





//Студент реализовал запрос баланса по карте и на банковском депозите:
let atm1 = ATM(
   userCardId: "4423 2500 6798 5925",
   userCardPin: 1234,
   someBank: bankClint,
   actions: .userPressBalanceInquiry
)
print (" ")


//Студент реализовал снятие наличных с карты
let atm2 = ATM(
   userCardId: "4423 2500 6798 5925",
   userCardPin: 1234,
   someBank: bankClint,
   actions: .userPressWithdrawalCash(withdraw: 300),
   withdrawal: .card
)
print (" ")


//Студент реализовал снятие наличных с банковского депозита
let atm3 = ATM(
   userCardId: "4423 2500 6798 5925",
   userCardPin: 1234,
   someBank: bankClint,
   actions: .userPressWithdrawalCash(withdraw: 500),
   withdrawal: .deposit
)
print (" ")


//Студент реализовал пополнение карты наличными:
let atm4 = ATM(
   userCardId: "4423 2500 6798 5925",
   userCardPin: 1234,
   someBank: bankClint,
   actions: .userPressTopUpAccount(topUp: 1000),
   topUping: .card,
   maxBanknotes: 40
)
print (" ")


//Студент реализовал пополнение  банковского депозита наличными:
let atm5 = ATM(
   userCardId: "4423 2500 6798 5925",
   userCardPin: 1234,
   someBank: bankClint,
   actions: .userPressTopUpAccount(topUp: 2000),
   topUping: .deposit,
   maxBanknotes: 20
)
print (" ")


//Студент реализовал пополнение баланса телефона наличными:
let atm6 = ATM(
   userCardId: "4423 2500 6798 5925",
   userCardPin: 1234,
   someBank: bankClint,
   actions: .userPressPayPhone(phone: "+79158888888"),
   payment: .cash(cash: 300)
)
print (" ")


//Студент реализовал пополнение баланса телефона с карты:
let atm7 = ATM(
   userCardId: "4423 2500 6798 5925",
   userCardPin: 1234,
   someBank: bankClint,
   actions: .userPressPayPhone(phone: "+79158888888"),
   payment: .card(card: 500)
)
print (" ")


//Студент реализовал обработку ошибок:
let atmError1 = ATM(
   userCardId: "4423 2500 6798 5925",
   userCardPin: 5555,
   someBank: bankClint,
   actions: .userPressBalanceInquiry
)
print (" ")

let atmError2 = ATM(
   userCardId: "4423 2500 6798 5925",
   userCardPin: 1234,
   someBank: bankClint,
   actions: .userPressPayPhone(phone: "+79158888889")
)
print (" ")

let atmError3 = ATM(
   userCardId: "4423 2500 6798 5925",
   userCardPin: 1234,
   someBank: bankClint,
   actions: .userPressPayPhone(phone: "+79158888888"),
   payment: .cash(cash: 5000)
)
print (" ")

let atmError4 = ATM(
   userCardId: "4423 2500 6798 5925",
   userCardPin: 1234,
   someBank: bankClint,
   actions: .userPressPayPhone(phone: "+79158888888"),
   payment: .card(card: 5000)
)
print (" ")

let atmError5 = ATM(
   userCardId: "4423 2500 6798 5925",
   userCardPin: 1234,
   someBank: bankClint,
   actions: .userPressTopUpAccount(topUp: 40000),
   topUping: .deposit,
   maxBanknotes: 30
)
print (" ")

let atmError6 = ATM(
   userCardId: "4423 2500 6798 5925",
   userCardPin: 1234,
   someBank: bankClint,
   actions: .userPressTopUpAccount(topUp: 1000),
   topUping: .deposit,
   maxBanknotes: 50
)
print (" ")

let atmError7 = ATM(
   userCardId: "4423 2500 6798 5925",
   userCardPin: 1234,
   someBank: bankClint,
   actions: .userPressTopUpAccount(topUp: 1000),
   topUping: .card,
   maxBanknotes: 41
)
print (" ")


let atmError8 = ATM(
   userCardId: "4423 2500 6798 5925",
   userCardPin: 1234,
   someBank: bankClint,
   actions: .userPressWithdrawalCash(withdraw: 30000)
)
print (" ")

let atmError9 = ATM(
   userCardId: "4423 2500 6798 5925",
   userCardPin: 1234,
   someBank: bankClint,
   actions: .userPressWithdrawalCash(withdraw: 4564),
   withdrawal: .card
)
print (" ")

let atmError10 = ATM(
   userCardId: "4423 2500 6798 5925",
   userCardPin: 1234,
   someBank: bankClint,
   actions: .userPressWithdrawalCash(withdraw: 4566),
   withdrawal: .deposit
)
print (" ")
